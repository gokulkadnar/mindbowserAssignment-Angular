import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HomeRoutingModule } from './home-routing.module';
import { EmployeedComponent } from './employeed/employeed.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AlertPopupComponent } from '../components/alert-popup/alert-popup.component';


@NgModule({
  declarations: [
    EmployeedComponent,
    AlertPopupComponent
  ],
  imports: [
    CommonModule,
    HomeRoutingModule,
    FormsModule,
    ReactiveFormsModule,
  ]
})
export class HomeModule { }
