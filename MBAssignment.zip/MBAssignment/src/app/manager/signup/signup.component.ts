import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/auth.service';
import { AlertPopupComponent } from 'src/app/components/alert-popup/alert-popup.component';
import { Manager } from 'src/app/model/managerTO';
import { ResultMessage } from 'src/app/model/REsultMessage';
declare var $: any;

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  reactiveForm: any;
  managerTo: Manager = {};
  resultMessage: ResultMessage = {};
  @ViewChild(AlertPopupComponent) alertBox?: AlertPopupComponent;
  errorMsg?: string;
  secret?: string = "mysecret";


  constructor(private formBuilder: FormBuilder, private authService: AuthService, private route: Router) { }

  ngOnInit() {

    if (this.authService.isLoggedIn()) {
      this.route.navigate(['employeelist']);
    }
    this.reactiveForm = this.formBuilder.group({
      email: [null, [Validators.required, Validators.email]],
      firstName: [null, Validators.required],
      lastName: [null, Validators.required],
      password: [null, [Validators.required, Validators.minLength(8)]],
      birthDate: [null, Validators.required],
      address: [null, Validators.required],
      company: [null, Validators.required],
    });

    $("#myModal").modal({ show: true, backdrop: "static" });


  }


  signUp() {

    this.authService.signUp(this.managerTo).subscribe(data => {
      this.resultMessage = data;
      this.alertBox?.openAlertPopup(this.resultMessage.resultMsg);
      if (this.resultMessage.resultType === 1) {
        this.route.navigate(['login']);
      }

      if (this.resultMessage.resultType === 0) {
        this.errorMsg = this.resultMessage.resultMsg;
      }
    },
      err => {
        this.errorMsg = "Error : Something went wrong"
      })

  }


  get email() {
    return this.reactiveForm.get('email');
  }

  get firstName() {
    return this.reactiveForm.get('firstName');
  }

  get lastName() {
    return this.reactiveForm.get('lastName');
  }

  get password() {
    return this.reactiveForm.get('password');
  }

  get birthDate() {
    return this.reactiveForm.get('birthDate');
  }

  get address() {
    return this.reactiveForm.get('address');
  }

  get company() {
    return this.reactiveForm.get('company');
  }

}

