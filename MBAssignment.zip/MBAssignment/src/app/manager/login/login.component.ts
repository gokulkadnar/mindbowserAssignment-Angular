import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/auth.service';
import { UserTo } from 'src/app/model/loginTo';
declare var $: any;


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  userTo: UserTo = {};
  reactiveForm: any;
  loginError? : string;
  currentUser : any;


  constructor(private _fb: FormBuilder, private authService: AuthService, private router: Router) { }

  ngOnInit(): void {
    debugger

    // Navigate to the employeelist if user is already logged in.
    if (this.authService.isLoggedIn()) {
      this.router.navigate(['employeelist']);
    }

    this.reactiveForm = this._fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    })

    $("#myModal").modal({ show: true, backdrop: "static" });

  }

  ngOnDestroy() {
    $('#modal').modal('toggle')

  }

  // Login use with email and password
  login() {
    this.authService.login(this.userTo).subscribe(data => {
      this.currentUser = data;
      if(this.currentUser.manager){
        this.authService.doLogin(this.currentUser.manager);
        this.router.navigate(['employeelist'])
      }

      // show error message if any
      if(this.currentUser.status === 0){
        this.loginError = this.currentUser.infoMsg;
      }
    },
      err => {
        this.loginError = "Something went wrong. Please check connection";
      }
    )
  }

  get email() {
    return this.reactiveForm.get('email');
  }

  get password() {
    return this.reactiveForm.get('password');
  }

}
