import { Component, OnInit } from '@angular/core';
declare var $: any;

@Component({
  selector: 'app-alert-popup',
  templateUrl: './alert-popup.component.html',
  styleUrls: ['./alert-popup.component.css']
})
export class AlertPopupComponent implements OnInit {

  alertMsg?: string;

  constructor() { }

  ngOnInit(): void {
  }

  // Open pop up box
  openAlertPopup(msg?: string) {
    if (msg) {
      this.alertMsg = msg
      $("#myModal").modal({ show: true, backdrop: "static" });

    }
  }
}
