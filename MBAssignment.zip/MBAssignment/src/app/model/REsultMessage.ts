export class ResultMessage {

	public resultType?: number;
	public resultMsg?: string
	public resultMessage?: string;

}