----------This is the normal Angular application with crud operation created by Gokul Kadnar-----------

Here is the some steps to run this application.

1. Clone application from git hub link
2. Open the application in Visual studio code
3. Before run the application you have to add all required dependancies from NPM by using the command - NPM i
4. Once all npm libraries downloaded run the angular application using command - ng serve
5. Once the code compiled open the browser and hit the link - http://localhost:4200/ OR respective Port number
6. now it will navigates to the manager login page
7. First create manager account by signin page
8. Once manager account is created you can log in with credentials
9. The you can access the application.


--------------------------Thank You Gokul Kadnar------------------------------
gtk0104@gmail.com
9175010104